import numpy as np
import matplotlib.pyplot as plt

def search_function_country_data(search_term):
    Country_data = open('Country_Data.csv')
    Country_data_array = np.genfromtxt(Country_data, dtype = str, delimiter = ',')
    indices_of_selected_data = []
    for i in range(0,195):
        if search_term == Country_data_array[i][0] or search_term == Country_data_array[i][1] or search_term == Country_data_array[i][2] or search_term == Country_data_array[i][3]:
            
            indices_of_selected_data.append(i)

    return indices_of_selected_data

def graphing_function_population(selected_data_list):
    Pop_data = open('Population_Data (1).csv')
    Population_data_array = np.genfromtxt(Pop_data, dtype = str, delimiter = ',')
    Country_data = open('Country_Data.csv')
    Country_data_array = np.genfromtxt(Country_data, dtype = str, delimiter = ',')
    Species_data = open('Threatened_Species.csv')
    Species_data_array = np.genfromtxt(Species_data, dtype = str, delimiter = ',')

    # Creates population density bar graph
    current_population_list = []
    square_km_list = []
    data_labels = []
    for i in (selected_data_list):

    # Fuck off monaco
        if i == 112:
            current_population_list.append(0)
            square_km_list.append(1)
            data_labels.append('Monaco(No Data)')
        elif i == 160:
            current_population_list.append(0)
            square_km_list.append(1)
            data_labels.append('South Sudan(No Data)')
        elif i == 166:
            current_population_list.append(0)
            square_km_list.append(1)
            data_labels.append('Sudan(No Data)')
        else:
            current_population_list.append(int(Population_data_array[i][21]))
            square_km_list.append(int(Country_data_array[i][3]))
            data_labels.append(Country_data_array[i][0])


    population_density_list = []
    for i in range(0,len(current_population_list)):
    
    # Fuck off again monaco
        if i == 112:
            population_density_list.append(0)
        elif i == 160:
            population_density_list.append(0)
        elif i == 166:
            population_density_list.append(0)
        else:
            population_density_list.append(current_population_list[i] // square_km_list[i])
    
    figure1 = plt.figure(1)
    plt.bar(data_labels, population_density_list, color = 'maroon', width = 0.4)
    plt.xticks(rotation = 'vertical', size = 6)
    plt.title('Population Density for Countries in the Given Area', size = 14)
    plt.xlabel('Countries')
    plt.ylabel('Current Population density (People per square km)')

    # Creates Average population growth per year graph
    avg_pop_growth_per_year = []
    for i in selected_data_list:
        avg_pop_growth_per_year.append((int(Population_data_array[i][21])-int(Population_data_array[i][1]))//21)
    
    figure2 = plt.figure(2)
    plt.bar(data_labels, avg_pop_growth_per_year, color = 'blue', width = 0.4)
    plt.xticks(rotation = 'vertical', size = 6)
    plt.title('Average Population Growth Per Year 2000-2021 for Countries in the Given Area', size = 14)
    plt.xlabel('Countries')
    plt.ylabel('Average Population Growth per Year (people per year)')


    plt.show()




def graphing_function_animal(selected_data):
    Pop_data = open('Population_Data (1).csv')
    Population_data_array = np.genfromtxt(Pop_data, dtype = str, delimiter = ',')
    Country_data = open('Country_Data.csv')
    Country_data_array = np.genfromtxt(Country_data, dtype = str, delimiter = ',')
    Species_data = open('Threatened_Species.csv')
    Species_data_array = np.genfromtxt(Species_data, dtype = str, delimiter = ',')

    #Graphs threatened species per sq km

    data_labels = []
    threatened_species_per_sq_km = []

    for i in selected_data:
        if i == 112:
            threatened_species_per_sq_km.append(0)
            data_labels.append('Monaco(No Data)')
        elif i == 160:
            threatened_species_per_sq_km.append(0)
            data_labels.append('South Sudan(No Data)')
        elif i == 166:
            threatened_species_per_sq_km.append(0)
            data_labels.append(0)
        else:
            data_labels.append(Country_data_array[i][0])
            threatened_species_per_sq_km.append((int(Species_data_array[i][1]) + int(Species_data_array[i][2]) + int(Species_data_array[i][3]) + int(Species_data_array[i][4]))/int(Country_data_array[i][3]))

    figure1 = plt.figure(1)
    plt.bar(data_labels, threatened_species_per_sq_km, color = 'cyan', width = 0.4)
    plt.xticks(rotation = 'vertical', size = 6)
    plt.title('Threatened Species Per Square Km for Countries in Given Region', size = 14)
    plt.xlabel('Countries')
    plt.ylabel('Threatened Species per Square Km')

    #Graphs threatened species vs current population for given countries

    avg_threatened_species_per_current_population = []
    for i in selected_data:
        if i == 112:
            avg_threatened_species_per_current_population.append(0)
        elif i == 160:
            avg_threatened_species_per_current_population.append(0)
        elif i == 166:
            avg_threatened_species_per_current_population.append(0)
        else:
            avg_threatened_species_per_current_population.append((int(Species_data_array[i][1]) + int(Species_data_array[i][2]) + int(Species_data_array[i][3]) + int(Species_data_array[i][4]))/int(Population_data_array[i][21]))
    
    figure2 = plt.figure(2)
    plt.bar(data_labels, avg_threatened_species_per_current_population, color = 'orange', width = 0.4)
    plt.xticks(rotation = 'vertical', size = 6)
    plt.title('Threatened species per Current Population for Given Region', size = 14)
    plt.xlabel('Countries')
    plt.ylabel('Threatened Species per Given Population')

    plt.show()

class country_stats:
    def __init__ (self,index):
        Pop_data = open('Population_Data (1).csv')
        Population_data_array = np.genfromtxt(Pop_data, dtype = str, delimiter = ',')
        Country_data = open('Country_Data.csv')
        Country_data_array = np.genfromtxt(Country_data, dtype = str, delimiter = ',')
        Species_data = open('Threatened_Species.csv')
        Species_data_array = np.genfromtxt(Species_data, dtype = str, delimiter = ',')

        self.name = Country_data_array[index][0]
        self.avg_pop_growth = (int(Population_data_array[index][21]) - int(Population_data_array[index][1]))/21
        self.pop_per_square_km = (int(Population_data_array[index][21]))/(int(Country_data_array[index][3]))
        self.current_pop = Population_data_array[index][21]

        population_numbers = []
        for i in range(1,22):
            population_numbers.append(Population_data_array[index][i])
        population_numbers_array = np.array(population_numbers)

        self.max_pop_2000_2021 = np.max(population_numbers_array.astype(int))
        self.min_pop_2000_2021 = np.min(population_numbers_array.astype(int))
        self.change_in_pop_2000_2021 = int(Population_data_array[index][21]) - int(Population_data_array[index][1])

        self.total_threatened_species = int(Species_data_array[index][1]) + int(Species_data_array[index][2]) + int(Species_data_array[index][3]) + int(Species_data_array[index][4])
        self.threatened_species_per_kmsq = (int(Species_data_array[index][1]) + int(Species_data_array[index][2]) + int(Species_data_array[index][3]) + int(Species_data_array[index][4]))/(int(Country_data_array[index][3]))
        self.threatened_species_per_current_pop = (int(Species_data_array[index][1]) + int(Species_data_array[index][2]) + int(Species_data_array[index][3]) + int(Species_data_array[index][4]))/(int(Population_data_array[index][21]))

    def print_all_stats(self):
        # I won't make this look nice because the GUI can do this.  Basically just goes through and prints out all of the attributes to self
        print(self.name)
        print(self.avg_pop_growth)
        print(self.pop_per_square_km)
        print(self.current_pop)
        print(self.max_pop_2000_2021)
        print(self.min_pop_2000_2021)
        print(self.change_in_pop_2000_2021)
        print(self.total_threatened_species)
        print(self.threatened_species_per_kmsq)
        print(self.threatened_species_per_current_pop)



class country_stats_for_monaco_south_sudan_sudan_because_they_are_special:
    def __init__ (self,index):
        Pop_data = open('Population_Data (1).csv')
        Population_data_array = np.genfromtxt(Pop_data, dtype = str, delimiter = ',')
        Country_data = open('Country_Data.csv')
        Country_data_array = np.genfromtxt(Country_data, dtype = str, delimiter = ',')
        Species_data = open('Threatened_Species.csv')
        Species_data_array = np.genfromtxt(Species_data, dtype = str, delimiter = ',')

        self.name = Country_data_array[index][0]
        self.avg_pop_growth = (int(Population_data_array[index][21]) - int(Population_data_array[index][1]))/21
        self.pop_per_square_km = "No Data Available"
        self.current_pop = Population_data_array[index][21]

        population_numbers = []
        for i in range(1,22):
            population_numbers.append(Population_data_array[index][i])
        population_numbers_array = np.array(population_numbers)

        self.max_pop_2000_2021 = np.max(population_numbers_array.astype(int))
        self.min_pop_2000_2021 = np.min(population_numbers_array.astype(int))
        self.change_in_pop_2000_2021 = int(Population_data_array[index][21]) - int(Population_data_array[index][1])

        self.total_threatened_species = int(Species_data_array[index][1]) + int(Species_data_array[index][2]) + int(Species_data_array[index][3]) + int(Species_data_array[index][4])
        self.threatened_species_per_kmsq = "No Data Available"
        self.threatened_species_per_current_pop = (int(Species_data_array[index][1]) + int(Species_data_array[index][2]) + int(Species_data_array[index][3]) + int(Species_data_array[index][4]))/(int(Population_data_array[index][21]))

    def print_all_stats(self):
        # I won't make this look nice because the GUI can do this.  Basically just goes through and prints out all of the attributes to self
        print(self.name)
        print(self.avg_pop_growth)
        print(self.pop_per_square_km)
        print(self.current_pop)
        print(self.max_pop_2000_2021)
        print(self.min_pop_2000_2021)
        print(self.change_in_pop_2000_2021)
        print(self.total_threatened_species)
        print(self.threatened_species_per_kmsq)
        print(self.threatened_species_per_current_pop)


# This would need to go in the main code, not in a function
# Initializes all selected data points as a class:


selected_data = search_function_country_data('Asia')

# This prints out all of the data points of the selected countries in the region.  This is part of GUI so I wont make it look nice

for i in selected_data:
    if i == 112 or i == 160 or i == 166:
        stats_class = country_stats_for_monaco_south_sudan_sudan_because_they_are_special(i)
        stats_class.print_all_stats()
    else:
        stats_class = country_stats(i)
        stats_class.print_all_stats()