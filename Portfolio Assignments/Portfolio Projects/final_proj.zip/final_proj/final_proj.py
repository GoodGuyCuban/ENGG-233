#This is an empty header cause the code looks really weird to me without it smh
#Kinda cool tho
#Made by slim jim Perez and big papa Tiessen
#We gonna make lots of $$$$$$$ with this and buy detroit and/or an island in the south seas to create a tax haven/mega parking lot for more $$$$$$$

import PySimpleGUI as sg
import os.path
import numpy as np
import matplotlib.pyplot as plt
from numpy.lib.function_base import delete
"""
This block creates the basic structure of the file list column in window
No inputs
"""
file_list_column = [ # Basically, all the gui stuff is done through nested lists, each one representing a component in an overall window EG, if multiple buttons are in one list, they'll be next to eachother 
            [
                sg.Text("CSV Folder"),
                sg.In(size=(25,1), enable_events=True, key="-FOLDER-"),
                sg.FolderBrowse(),
            ],
            [
                sg.Listbox(
                    values=[], enable_events=True, size=(40,20),
                    key="-FILE LIST-"
                )
            ],
        ]

"""
This block creates the basic structure of the csv column in window
No inputs
"""
csv_viewer_column = [
    [sg.Text("Choose a CSV file from the list on the left:")],
    [sg.Text(size=(40,1), key="-TARGETNAME-", text='No document selected')],
    [sg.Button('Import'), sg.Button('Search'), sg.Button('Graph'), sg.Button('Check Stats')],
    [sg.HSeparator()],
    [sg.Listbox(
        values=[], size=(20,10),
        key="-IMPORT LIST-"
    )]
]

"""
This block pieces together the two previous blocks into one window
No inputs
"""
layout = [
    [
        sg.Column(file_list_column),
        sg.VSeparator(),
        sg.Column(csv_viewer_column),
    ]
]

class country_stats:
    def __init__ (self, index, Population_data_array, Country_data_array, Species_data_array):
        
        self.name = Country_data_array[index][0]
        self.avg_pop_growth = (int(Population_data_array[index][21]) - int(Population_data_array[index][1]))/21
        self.pop_per_square_km = (int(Population_data_array[index][21]))/(int(Country_data_array[index][3]))
        self.current_pop = Population_data_array[index][21]

        population_numbers = []
        for i in range(1,22):
            population_numbers.append(Population_data_array[index][i])
        population_numbers_array = np.array(population_numbers)

        self.max_pop_2000_2021 = np.max(population_numbers_array.astype(int))
        self.min_pop_2000_2021 = np.min(population_numbers_array.astype(int))
        self.change_in_pop_2000_2021 = int(Population_data_array[index][21]) - int(Population_data_array[index][1])

        self.total_threatened_species = int(Species_data_array[index][1]) + int(Species_data_array[index][2]) + int(Species_data_array[index][3]) + int(Species_data_array[index][4])
        self.threatened_species_per_kmsq = (int(Species_data_array[index][1]) + int(Species_data_array[index][2]) + int(Species_data_array[index][3]) + int(Species_data_array[index][4]))/(int(Country_data_array[index][3]))
        self.threatened_species_per_current_pop = (int(Species_data_array[index][1]) + int(Species_data_array[index][2]) + int(Species_data_array[index][3]) + int(Species_data_array[index][4]))/(int(Population_data_array[index][21]))

    def print_all_stats(self):
        # I won't make this look nice because the GUI can do this.  Basically just goes through and prints out all of the attributes to self
        sg.Window(title='Output',layout=[[sg.Text('Country: '+str(self.name))],[sg.Text('Average population growth: '+str(self.avg_pop_growth))],[sg.Text('Population per square km: '+str(self.pop_per_square_km))],\
            [sg.Text('Current population: '+str(self.current_pop))],[sg.Text('Maximum population (2000-2021): '+str(self.max_pop_2000_2021))],[sg.Text('Minimum population (2000-2021): '+str(self.min_pop_2000_2021))],\
                [sg.Text('Change in population (2000-2021): '+str(self.change_in_pop_2000_2021))],[sg.Text('Total threatened species: '+str(self.total_threatened_species))],[sg.Text('Threatened species per square km: '+str(self.threatened_species_per_kmsq))],\
                    [sg.Text('Threatened species per current population: '+str(self.threatened_species_per_current_pop))]],margins=(100,5)).read()

class country_stats_for_monaco_south_sudan_sudan_because_they_are_special:
    def __init__ (self, index, Population_data_array, Country_data_array, Species_data_array):
        
        self.name = Country_data_array[index][0]
        self.avg_pop_growth = (int(Population_data_array[index][21]) - int(Population_data_array[index][1]))/21
        self.pop_per_square_km = "No Data Available"
        self.current_pop = Population_data_array[index][21]

        population_numbers = []
        for i in range(1,22):
            population_numbers.append(Population_data_array[index][i])
        population_numbers_array = np.array(population_numbers)

        self.max_pop_2000_2021 = np.max(population_numbers_array.astype(int))
        self.min_pop_2000_2021 = np.min(population_numbers_array.astype(int))
        self.change_in_pop_2000_2021 = int(Population_data_array[index][21]) - int(Population_data_array[index][1])

        self.total_threatened_species = int(Species_data_array[index][1]) + int(Species_data_array[index][2]) + int(Species_data_array[index][3]) + int(Species_data_array[index][4])
        self.threatened_species_per_kmsq = "No Data Available"
        self.threatened_species_per_current_pop = (int(Species_data_array[index][1]) + int(Species_data_array[index][2]) + int(Species_data_array[index][3]) + int(Species_data_array[index][4]))/(int(Population_data_array[index][21]))

    def print_all_stats(self):
        # I won't make this look nice because the GUI can do this.  Basically just goes through and prints out all of the attributes to self
        sg.Window(title='Output',layout=[[sg.Text('Country: '+str(self.name))],[sg.Text('Average population growth: '+str(self.avg_pop_growth))],[sg.Text('Population per square km: '+str(self.pop_per_square_km))],\
            [sg.Text('Current population: '+str(self.current_pop))],[sg.Text('Maximum population (2000-2021): '+str(self.max_pop_2000_2021))],[sg.Text('Minimum population (2000-2021): '+str(self.min_pop_2000_2021))],\
                [sg.Text('Change in population (2000-2021): '+str(self.change_in_pop_2000_2021))],[sg.Text('Total threatened species: '+str(self.total_threatened_species))],[sg.Text('Threatened species per square km: '+str(self.threatened_species_per_kmsq))],\
                    [sg.Text('Threatened species per current population: '+str(self.threatened_species_per_current_pop))]],margins=(100,5)).read()

window = sg.Window("ENDG 233 Statistics Project", layout) # Creating the window object with the previously established layout

"""
This function checks if a document/file is currently being selected
Takes in a window variable
"""
def selection_check(window_local):
    if window_local["-TARGETNAME-"].get() != 'No document selected':
        return True
    else:
        sg.Window(title='Error',layout=[[sg.Text("No document selected")]],margins=(100,1)).read()
        return False

def error_prompt(error_message):
    sg.Window(title='Error',layout=[[sg.Text(error_message)]],margins=(100,1)).read()

def search_function_country_data(search_term, selected_array):
    
    Country_data_array = selected_array
    indicies_of_selected_data = []
    for i in range(0,195):
        if search_term == Country_data_array[i][0] or search_term == Country_data_array[i][1] or search_term == Country_data_array[i][2] or search_term == Country_data_array[i][3]:
            indicies_of_selected_data.append(i)
    if indicies_of_selected_data == []:
        indicies_of_selected_data = 'No value found'
    return indicies_of_selected_data    
    
def graphing_function_population(selected_data_list, Population_data_array, Country_data_array):
    
    selected_data_list = np.delete(selected_data_list, (0), axis=0)
    Population_data_array = np.delete(Population_data_array, (0), axis=0)
    Country_data_array = np.delete(Country_data_array, (0), axis=0)
    # Creates population density bar graph
    current_population_list = []
    square_km_list = []
    data_labels = []

    for i, x in enumerate(selected_data_list):
        # Fuck off monaco
        if i == 111:
            current_population_list.append(0)
            square_km_list.append(1)
            data_labels.append('Monaco(No Data)')
        elif i == 159:
            current_population_list.append(0)
            square_km_list.append(1)
            data_labels.append('South Sudan(No Data)')
        elif i == 165:
            current_population_list.append(0)
            square_km_list.append(1)
            data_labels.append('Sudan(No Data)')
        else:
            current_population_list.append(int(Population_data_array[i][21]))
            square_km_list.append(int(Country_data_array[i][3]))
            data_labels.append(Country_data_array[i][0])


    population_density_list = []
    for i in range(0,len(current_population_list)):
    
    # Fuck off again monaco
        if i == 112:
            population_density_list.append(0)
        elif i == 160:
            population_density_list.append(0)
        elif i == 166:
            population_density_list.append(0)
        else:
            population_density_list.append(current_population_list[i] // square_km_list[i])
    
    figure1 = plt.figure(1)
    plt.bar(data_labels, population_density_list, color = 'maroon', width = 0.4)
    plt.xticks(rotation = 'vertical', size = 6)
    plt.title('Population Density for Countries in the Given Area', size = 14)
    plt.xlabel('Countries')
    plt.ylabel('Current Population density (People per square km)')

    # Creates Average population growth per year graph
    avg_pop_growth_per_year = []
    for i, x in enumerate(selected_data_list):
        avg_pop_growth_per_year.append((int(Population_data_array[i][21])-int(Population_data_array[i][1]))//21)
    
    figure2 = plt.figure(2)
    plt.bar(data_labels, avg_pop_growth_per_year, color = 'blue', width = 0.4)
    plt.xticks(rotation = 'vertical', size = 6)
    plt.title('Average Population Growth Per Year 2000-2021 for Countries in the Given Area', size = 14)
    plt.xlabel('Countries')
    plt.ylabel('Average Population Growth per Year (people per year)')


    plt.show()

def graphing_function_animal(selected_data_list, Population_data_array, Country_data_array, Species_data_array):
    
    selected_data_list = np.delete(selected_data_list, (0), axis=0)
    Population_data_array = np.delete(Population_data_array, (0), axis=0)
    Country_data_array = np.delete(Country_data_array, (0), axis=0)
    Species_data_array = np.delete(Species_data_array, (0), axis=0)
    #Graphs threatened species per sq km

    data_labels = []
    threatened_species_per_sq_km = []

    for i,x in enumerate(selected_data_list):
        if i == 111:
            threatened_species_per_sq_km.append(0)
            data_labels.append('Monaco(No Data)')
        elif i == 159:
            threatened_species_per_sq_km.append(0)
            data_labels.append('South Sudan(No Data)')
        elif i == 165:
            threatened_species_per_sq_km.append(0)
            data_labels.append('0')
        else:
            data_labels.append(Country_data_array[i][0])
            threatened_species_per_sq_km.append((int(Species_data_array[i][1]) + int(Species_data_array[i][2]) + int(Species_data_array[i][3]) + int(Species_data_array[i][4]))/int(Country_data_array[i][3]))

    figure1 = plt.figure(1)
    plt.bar(data_labels, threatened_species_per_sq_km, color = 'cyan', width = 0.4)
    plt.xticks(rotation = 'vertical', size = 6)
    plt.title('Threatened Species Per Square Km for Countries in Given Region', size = 14)
    plt.xlabel('Countries')
    plt.ylabel('Threatened Species per Square Km')

    #Graphs threatened species vs current population for given countries

    avg_threatened_species_per_current_population = []
    for i,x in enumerate(selected_data_list):
        if i == 111:
            avg_threatened_species_per_current_population.append(0)
        elif i == 159:
            avg_threatened_species_per_current_population.append(0)
        elif i == 165:
            avg_threatened_species_per_current_population.append(0)
        else:
            avg_threatened_species_per_current_population.append((int(Species_data_array[i][1]) + int(Species_data_array[i][2]) + int(Species_data_array[i][3]) + int(Species_data_array[i][4]))/int(Population_data_array[i][21]))
    
    figure2 = plt.figure(2)
    plt.bar(data_labels, avg_threatened_species_per_current_population, color = 'orange', width = 0.4)
    plt.xticks(rotation = 'vertical', size = 6)
    plt.title('Threatened species per Current Population for Given Region', size = 14)
    plt.xlabel('Countries')
    plt.ylabel('Threatened Species per Given Population')

    plt.show()


"""
Main function
"""
def main():
    selection_list = []
    array1 = []
    array2 = []
    array3 = []
    array1_name = ''
    array2_name = ''
    array3_name = ''
    arraydict = {}

    while True:
        event, values = window.read() # Activates and reads the menu

        if event == "Exit" or event == sg.WIN_CLOSED: # Breaks out of the loop if the window has been closed
            break

        if event == "-FOLDER-": 
            folder = values["-FOLDER-"]
            try:
                file_list = os.listdir(folder)
            except:
                file_list = []

            fnames = [
                f for f in file_list if os.path.isfile(os.path.join(folder, f)) and f.lower().endswith((".csv"))
            ]
            window["-FILE LIST-"].update(fnames)
        
        if event == "Import":
            if values["-FILE LIST-"]:
                if len(selection_list) < 3:
                    if np.array(array1).size == 0 and values["-FILE LIST-"][0] not in selection_list:
                        array1 = np.genfromtxt(os.path.join(values["-FOLDER-"], values["-FILE LIST-"][0]), dtype = str, delimiter=',')
                        array1_name = values["-FILE LIST-"][0]
                        arraydict[array1_name] = array1

                    elif np.array(array2).size == 0 and values["-FILE LIST-"][0] not in selection_list:
                        array2 = np.genfromtxt(os.path.join(values["-FOLDER-"], values["-FILE LIST-"][0]), dtype = str, delimiter=',')
                        array2_name = values["-FILE LIST-"][0]
                        arraydict[array2_name] = array2

                    elif np.array(array3).size == 0 and values["-FILE LIST-"][0] not in selection_list:
                        array3 = np.genfromtxt(os.path.join(values["-FOLDER-"], values["-FILE LIST-"][0]), dtype = str, delimiter=',')
                        array3_name = values["-FILE LIST-"][0]
                        arraydict[array3_name] = array3

                    selection_list.append(values["-FILE LIST-"][0])
                    selection_list = list(set(selection_list))
                    
                    window["-IMPORT LIST-"].update(selection_list)
                else:
                    error_prompt('Already Imported Max. 3')
            else:
                error_prompt('Please select folder first')
        if event == "Search":

            is_valid = selection_check(window)
            if is_valid == True:
                window2 = sg.Window(title='Selection',layout=[[sg.Text("Provide a header name")],[sg.Input(key = '-HEADER INPUT-'),sg.Button('OK')]],margins=(100,1))
                event1, values1 = window2.read()
                if event1 == 'OK':
                    window2.close()
                input_header = values1['-HEADER INPUT-']

                if values["-IMPORT LIST-"][0] == array1_name:
                    sg.Window(title='Output',layout=[[sg.Text(search_function_country_data(input_header, array1))]],margins=(100,1)).read()
                    
                elif values["-IMPORT LIST-"][0] == array2_name:
                    sg.Window(title='Output',layout=[[sg.Text(search_function_country_data(input_header, array2))]],margins=(100,1)).read()

                elif values["-IMPORT LIST-"][0] == array3_name:
                    sg.Window(title='Output',layout=[[sg.Text(search_function_country_data(input_header, array3))]],margins=(100,1)).read()

                else:
                    error_prompt('Please select a valid file')

        if event == "Graph":
            if values["-IMPORT LIST-"][0] == 'Population_Data.csv':
                
                pop_array = np.genfromtxt(os.path.join(values["-FOLDER-"], values["-IMPORT LIST-"][0]), dtype = str, delimiter=',')
                window2 = sg.Window(title='Selection',layout=[[sg.Text("Enter a year")],[sg.Input(key = '-YEAR INPUT-'),sg.Button('OK')]],margins=(100,1))
                event1, values1 = window2.read()

                if event1 == 'OK':
                    window2.close()
                year_selection = int(values1['-YEAR INPUT-'])


                if array1_name == 'Country_Data.csv':
                    graphing_function_population(pop_array[:,year_selection], pop_array, array1)

            elif values["-IMPORT LIST-"][0] == 'Threatened_Species.csv':

                species_array = np.genfromtxt(os.path.join(values["-FOLDER-"], values["-IMPORT LIST-"][0]), dtype = str, delimiter=',')
                index_array = range(0, 195)

                if array1_name == 'Country_Data.csv' and array2_name == 'Population_Data.csv':
                    graphing_function_animal(index_array, array2, array1, species_array)

                elif array1_name == 'Country_Data.csv' and array3_name == 'Population_Data.csv':
                    graphing_function_animal(index_array, array3, array1, species_array)

                elif array2_name == 'Country_Data.csv' and array1_name == 'Population_Data.csv':
                    graphing_function_animal(index_array, array1, array2, species_array)

                elif array2_name == 'Country_Data.csv' and array3_name == 'Population_Data.csv':
                    graphing_function_animal(index_array, array3, array2, species_array) 

                elif array3_name == 'Country_Data.csv' and array2_name == 'Population_Data.csv':
                    graphing_function_animal(index_array, array2, array3, species_array)

                elif array3_name == 'Country_Data.csv' and array1_name == 'Population_Data.csv':
                    graphing_function_animal(index_array, array1, array3, species_array)    

        if event == "Check Stats":
            window2 = sg.Window(title='Selection',layout=[[sg.Text("Enter an index")],[sg.Input(key = '-INDEX-'),sg.Button('OK')]],margins=(100,1))
            event1, values1 = window2.read()
            if event1 == 'OK':
                    window2.close()
            if 'Country_Data.csv' in arraydict:
                if arraydict['Country_Data.csv'][int(values1['-INDEX-'])][3] == '':
                    country_stats_for_monaco_south_sudan_sudan_because_they_are_special(int(values1['-INDEX-']), arraydict['Population_Data.csv'], arraydict['Country_Data.csv'], arraydict['Threatened_Species.csv']).print_all_stats()
                else:
                    country_stats(int(values1['-INDEX-']), arraydict['Population_Data.csv'], arraydict['Country_Data.csv'], arraydict['Threatened_Species.csv']).print_all_stats()
            else:
                error_prompt('Please import a valid file')
            
        elif event == "-FILE LIST-":
            try:
                filename = os.path.join(values["-FOLDER-"], values["-FILE LIST-"][0])
                window["-TARGETNAME-"].update(filename)
                
            except:
                pass
        
    window.close()    
        
if __name__ == '__main__':
    main()

    